export function registerMetricsRoutes(app, { auth, db }) {
  // Admin metrics for dashboard charts
  app.get("/api/admin/metrics", auth(["ADMIN"]), async (req, res) => {
    await db.read();
    const cases = db.data.cases || [];

    const status = {
      approved: cases.filter((c) => c.status === "APPROVED").length,
      pending: cases.filter((c) => c.status === "PENDING").length,
      rejected: cases.filter((c) => c.status === "REJECTED").length,
    };

    const byCategory = {};
    const byUrgency = {};
    for (const c of cases) {
      const cat = c.category || "Autre";
      byCategory[cat] = (byCategory[cat] || 0) + 1;

      const u = c.urgency || "NORMAL";
      byUrgency[u] = (byUrgency[u] || 0) + 1;
    }

    const topViewed = [...cases]
      .filter((c) => c.status !== "REJECTED")
      .sort((a, b) => (b.views || 0) - (a.views || 0))
      .slice(0, 6)
      .map((c) => ({ id: c.id, title: c.title, views: c.views || 0 }));

    res.json({ status, byCategory, byUrgency, topViewed });
  });
}
