import { nanoid } from "nanoid";

function sampleCases(ownerEmail = "association@solicare.tn") {
  const now = Date.now();
  const mk = (i, data) => ({
    id: nanoid(),
    ownerEmail,
    status: data.status ?? "APPROVED",
    createdAt: new Date(now - i * 86400000).toISOString(),
    views: Math.floor(Math.random() * 120),
    donationsCount: Math.floor(Math.random() * 12),
    raisedAmount: Math.floor(Math.random() * 1500),
    featured: data.featured ?? false,
    ...data,
  });

  return [
    mk(1, {
      title: "Fauteuil roulant pour Amal (Ariana)",
      summary: "Achat d’un fauteuil roulant adapté + séances de rééducation.",
      description:
        "Amal a besoin d’un fauteuil roulant adapté et de quelques séances de rééducation. Votre don aidera à améliorer sa mobilité et son autonomie.",
      category: "Handicap",
      urgency: "URGENT",
      locationText: "Ariana, Tunisie",
      lat: 36.8665,
      lng: 10.1647,
      cha9a9aUrl: "https://cha9a9a.tn/don/amal-fauteuil",
      photos: [
        "https://images.unsplash.com/photo-1580281657525-5f1b0d1d0002?auto=format&fit=crop&w=1200&q=60",
      ],
      goalAmount: 2000,
      featured: true,
    }),
    mk(2, {
      title: "Médicaments urgents – traitement 1 mois",
      summary: "Traitement médical urgent pour un patient en situation précaire.",
      description:
        "Financement de médicaments nécessaires pour un mois de traitement. L’objectif est d’éviter une complication et de stabiliser l’état de santé.",
      category: "Santé",
      urgency: "TRES_URGENT",
      locationText: "Ariana, Tunisie",
      lat: 36.8665,
      lng: 10.1647,
      cha9a9aUrl: "https://cha9a9a.tn/don/traitement-urgent",
      photos: [
        "https://images.unsplash.com/photo-1580281658628-3a7e7b6cc7a3?auto=format&fit=crop&w=1200&q=60",
      ],
      goalAmount: 1200,
      featured: true,
    }),
    mk(3, {
      title: "Kit scolaire pour 30 enfants",
      summary: "Cartables + fournitures pour des enfants de familles à faible revenu.",
      description:
        "Distribution de cartables et fournitures scolaires à 30 enfants. Chaque don contribue à la réussite scolaire et à l’égalité des chances.",
      category: "Enfants",
      urgency: "NORMAL",
      locationText: "Ariana, Tunisie",
      lat: 36.8665,
      lng: 10.1647,
      cha9a9aUrl: "https://cha9a9a.tn/don/kit-scolaire",
      photos: [
        "https://images.unsplash.com/photo-1519452575417-564c1401ecc0?auto=format&fit=crop&w=1200&q=60",
      ],
      goalAmount: 900,
    }),
    mk(4, {
      title: "Réparation toiture – famille en danger",
      summary: "Réparer une toiture endommagée avant les pluies.",
      description:
        "La toiture est endommagée et met la famille en danger. Les fonds serviront à acheter matériaux et main d’œuvre pour sécuriser le logement.",
      category: "Rénovation",
      urgency: "URGENT",
      locationText: "Ariana, Tunisie",
      lat: 36.8665,
      lng: 10.1647,
      cha9a9aUrl: "https://cha9a9a.tn/don/toiture",
      photos: [
        "https://images.unsplash.com/photo-1600566753141-7d51bcd117c7?auto=format&fit=crop&w=1200&q=60",
      ],
      goalAmount: 3000,
    }),
    mk(5, {
      title: "Soutien psychologique – enfant TSA",
      summary: "Aider un enfant autiste à accéder à des séances spécialisées.",
      description:
        "Financer des séances spécialisées et matériel éducatif pour un enfant avec troubles du spectre autistique. Objectif: progression et inclusion.",
      category: "Handicap",
      urgency: "NORMAL",
      locationText: "Ariana, Tunisie",
      lat: 36.8665,
      lng: 10.1647,
      cha9a9aUrl: "https://cha9a9a.tn/don/tsa",
      photos: [
        "https://images.unsplash.com/photo-1598257006462-7c64a220d8b1?auto=format&fit=crop&w=1200&q=60",
      ],
      goalAmount: 1500,
    }),
  ];
}

export function registerSeedRoutes(app, { auth, db }) {
  // Dev: seed database with sample cases (admin only)
  app.post("/api/dev/seed", auth(["ADMIN"]), async (req, res) => {
    await db.read();
    db.data.cases ||= [];
    const existing = db.data.cases.length;

    const add = sampleCases();
    db.data.cases.push(...add);

    await db.write();
    res.json({ ok: true, added: add.length, before: existing, after: db.data.cases.length });
  });

  // Dev: reset cases (admin only)
  app.post("/api/dev/reset", auth(["ADMIN"]), async (req, res) => {
    await db.read();
    db.data.cases = [];
    await db.write();
    res.json({ ok: true });
  });
}
