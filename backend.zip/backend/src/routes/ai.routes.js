// AI endpoints: rule-based (offline) to keep the demo fully functional without external APIs.
//
// - /api/ai/match : parse donor intent and recommend 3 cases
// - /api/ai/chat  : donor assistant chatbot (FAQ + dynamic info)
// - /api/ai/admin-review : admin assistant for credibility scoring / recommendation

function norm(s) {
  return String(s || "").toLowerCase();
}

function pickUrgencyRank(u) {
  if (u === "TRES_URGENT") return 3;
  if (u === "URGENT") return 2;
  return 1;
}

function inferPreferences(query) {
  const q = norm(query);

  // location
  let location = null;
  const locs = ["ariana", "tunis", "manouba", "ben arous", "nabeul", "sousse", "sfax"];
  for (const l of locs) {
    if (q.includes(l)) { location = l; break; }
  }

  // urgency
  let urgency = null;
  if (q.includes("très urgent") || q.includes("tres urgent") || q.includes("critique")) urgency = "TRES_URGENT";
  else if (q.includes("urgent") || q.includes("vite")) urgency = "URGENT";

  // category
  let category = null;
  const cats = [
    { key: "santé", match: ["santé", "sante", "médic", "medic", "hopital", "opération", "operation"], value: "Santé" },
    { key: "handicap", match: ["handicap", "fauteuil", "autisme", "tsa", "aveugle", "sourd"], value: "Handicap" },
    { key: "enfants", match: ["enfant", "bébé", "bebe", "orphelin"], value: "Enfants" },
    { key: "éducation", match: ["école", "ecole", "education", "formation", "livre"], value: "Éducation" },
    { key: "rénovation", match: ["rénov", "renov", "maison", "toiture", "travaux"], value: "Rénovation" },
  ];
  for (const c of cats) {
    if (c.match.some((m) => q.includes(m))) { category = c.value; break; }
  }

  return { location, urgency, category };
}

function scoreCase(c, prefs) {
  let score = 0;
  const addr = norm(c.locationText || c.address || "");
  if (prefs.location && addr.includes(prefs.location)) score += 4;

  if (prefs.category && c.category === prefs.category) score += 4;

  if (prefs.urgency) {
    score += (pickUrgencyRank(c.urgency) === pickUrgencyRank(prefs.urgency)) ? 3 : 0;
    score += (pickUrgencyRank(c.urgency) > pickUrgencyRank(prefs.urgency)) ? 1 : 0;
  } else {
    score += pickUrgencyRank(c.urgency); // prefer urgent by default
  }

  // bonus: verified + featured + recent
  if (c.status === "APPROVED") score += 2;
  if (c.featured) score += 1;

  const ageDays = (Date.now() - new Date(c.createdAt || Date.now()).getTime()) / 86400000;
  if (ageDays < 10) score += 1;

  return score;
}

function makeReason(c, prefs) {
  const parts = [];
  if (prefs.location && norm(c.locationText || c.address).includes(prefs.location)) parts.push("proche de votre zone");
  if (prefs.category && c.category === prefs.category) parts.push("catégorie correspondante");
  if (prefs.urgency && c.urgency === prefs.urgency) parts.push("même niveau d'urgence");
  if (c.urgency !== "NORMAL" && !prefs.urgency) parts.push("besoin urgent");
  if (c.status === "APPROVED") parts.push("cas vérifié");
  return parts.length ? parts.join(" • ") : "bon impact social";
}

function donorFaqAnswer(message, { cases, stats }) {
  const m = norm(message);

  if (m.includes("cha9a9a") && (m.includes("comment") || m.includes("how") || m.includes("don"))) {
    return "Pour donner via Cha9a9a : ouvrez la fiche du cas → cliquez sur ‘Donner via Cha9a9a’ → confirmez le paiement. Vous pouvez partager le lien du cas à vos proches.";
  }

  if (m.includes("urgent") || m.includes("urgence")) {
    const urgent = cases
      .filter((c) => c.status === "APPROVED" && c.urgency !== "NORMAL")
      .sort((a, b) => pickUrgencyRank(b.urgency) - pickUrgencyRank(a.urgency))
      .slice(0, 5);
    if (!urgent.length) return "Pour l’instant, aucun cas urgent n’est publié. Revenez plus tard !";
    const lines = urgent.map((c, i) => `${i + 1}) ${c.title} (${c.category}, ${c.urgency})`).join("\n");
    return "Voici les cas urgents publiés :\n" + lines;
  }

  if (m.includes("stat") || m.includes("chiffre") || m.includes("stats")) {
    return `Statistiques : ${stats.total} cas au total, ${stats.approved} vérifiés, ${stats.urgent} urgents.`;
  }

  if (m.includes("universelle") || m.includes("ariana") || m.includes("association")) {
    return "Universelle Ariana mène des actions solidaires (aide aux familles, santé, inclusion). Sur SoliCare, elle publie des cas, puis l’admin les vérifie pour rassurer les donateurs.";
  }

  if (m.includes("bénévole") || m.includes("benevole") || m.includes("volont")) {
    return "Pour devenir bénévole : contactez Universelle Ariana via Facebook ou email, indiquez vos disponibilités, compétences et zone. Nous vous orienterons vers une action utile.";
  }

  if (m.includes("vérifier") || m.includes("verifier") || m.includes("validation")) {
    return "Vérification : une association soumet un cas (PENDING). Un admin contrôle cohérence + preuves, puis APPROVE (visible + badge vérifié) ou REJECT.";
  }

  // Default
  return "Je peux aider : recommander des cas (ex: ‘Ariana urgent médical’), expliquer Cha9a9a, montrer les urgences, et donner des statistiques. Posez votre question !";
}

function credibilityReview(caseItem) {
  // Simple heuristics for admin: check completeness, Cha9a9a URL domain, suspicious terms.
  const issues = [];
  const warnings = [];

  if (!caseItem.title || caseItem.title.length < 5) issues.push("Titre trop court");
  if (!caseItem.description || caseItem.description.length < 40) issues.push("Description trop courte");
  if (!caseItem.cha9a9aUrl || !String(caseItem.cha9a9aUrl).startsWith("https://")) issues.push("Lien Cha9a9a manquant ou invalide");
  if (!caseItem.photos || caseItem.photos.length === 0) warnings.push("Pas de photos (preuves)" );
  if (!caseItem.locationText && (caseItem.lat == null || caseItem.lng == null)) warnings.push("Localisation non précisée");

  const d = norm(caseItem.description);
  const suspicious = ["argent cash", "transfert", "western union", "bitcoin", "usdt", "compte perso", "iban perso"];
  if (suspicious.some((x) => d.includes(x))) issues.push("Mention de modes de paiement non officiels");

  let score = 70;
  score -= issues.length * 25;
  score -= warnings.length * 10;
  if (String(caseItem.cha9a9aUrl || "").includes("cha9a9a")) score += 5;
  score = Math.max(0, Math.min(100, score));

  let credibility = "FORT";
  if (score < 45) credibility = "FAIBLE";
  else if (score < 70) credibility = "MOYEN";

  let recommendation = "APPROVE";
  if (credibility === "FAIBLE") recommendation = "REJECT";
  else if (credibility === "MOYEN") recommendation = "NEED_MORE_INFO";

  const reasons = [
    ...(issues.length ? ["Problèmes: " + issues.join(", ")] : []),
    ...(warnings.length ? ["Risques: " + warnings.join(", ")] : []),
  ];

  return { score, credibility, recommendation, reasons, issues, warnings };
}

export function registerAiRoutes(app, { db }) {
  app.post("/api/ai/match", async (req, res) => {
    await db.read();
    const query = req.body?.query || "";
    const prefs = inferPreferences(query);

    const cases = (db.data.cases || []).filter((c) => c.status === "APPROVED");
    const scored = cases
      .map((c) => ({ c, s: scoreCase(c, prefs) }))
      .sort((a, b) => b.s - a.s)
      .slice(0, 3)
      .map(({ c }) => ({
        id: c.id,
        title: c.title,
        summary: c.summary || c.description,
        category: c.category,
        urgency: c.urgency,
        address: c.locationText || c.address || "",
        cha9a9aUrl: c.cha9a9aUrl,
        reason: makeReason(c, prefs),
      }));

    const note = prefs.location || prefs.category || prefs.urgency
      ? "Recommandations basées sur votre demande."
      : "Astuce: précisez votre zone (Ariana), urgence et catégorie pour des recommandations plus précises.";

    res.json({ recommendations: scored, note, prefs });
  });

  app.post("/api/ai/chat", async (req, res) => {
    await db.read();
    const message = req.body?.message || "";

    const cases = db.data.cases || [];
    const stats = {
      total: cases.length,
      approved: cases.filter((c) => c.status === "APPROVED").length,
      urgent: cases.filter((c) => c.status === "APPROVED" && c.urgency !== "NORMAL").length,
    };

    const answer = donorFaqAnswer(message, { cases, stats });
    res.json({ answer, stats });
  });

  app.post("/api/ai/admin-review", auth ? auth(["ADMIN"]) : (req,res,next)=>next(), async (req, res) => {
    await db.read();
    const id = req.body?.caseId;
    const c = (db.data.cases || []).find((x) => x.id === id);
    if (!c) return res.status(404).json({ message: "Not found" });

    const review = credibilityReview(c);
    res.json({ caseId: id, ...review });
  });
}
