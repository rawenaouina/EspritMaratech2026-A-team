export function registerFeaturedRoutes(app, { auth, db }) {
  // Public featured cases (only approved + featured)
  app.get("/api/cases/featured", async (req, res) => {
    await db.read();
    const items = (db.data.cases || [])
      .filter((c) => c.status === "APPROVED" && c.featured === true)
      .sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""))
      .slice(0, 10);
    res.json({ items });
  });

  // Admin: toggle featured
  app.patch("/api/admin/cases/:id/featured", auth(["ADMIN"]), async (req, res) => {
    await db.read();
    const c = (db.data.cases || []).find((x) => x.id === req.params.id);
    if (!c) return res.status(404).json({ message: "Not found" });
    c.featured = !!req.body.featured;
    await db.write();
    res.json({ ok: true, item: c });
  });
}
