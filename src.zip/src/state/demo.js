const KEY = "demo_mode_v1";
const CASES_KEY = "demo_cases_v1";

export function isDemoMode() {
  return localStorage.getItem(KEY) === "1";
}

export function setDemoMode(next) {
  localStorage.setItem(KEY, next ? "1" : "0");
}

export function getDemoCases() {
  try {
    const raw = localStorage.getItem(CASES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function setDemoCases(items) {
  localStorage.setItem(CASES_KEY, JSON.stringify(items));
}

export function seedDemoData() {
  const now = new Date();
  const mk = (i, o) => ({
    id: `demo-${i}`,
    title: o.title,
    description: o.description,
    summary: o.summary,
    category: o.category,
    urgency: o.urgency, // NORMAL | URGENT | TRES_URGENT
    status: o.status,   // PENDING | APPROVED | REJECTED
    views: o.views ?? Math.floor(20 + Math.random() * 300),
    goalAmount: o.goalAmount ?? 5000,
    totalAmount: o.totalAmount ?? Math.floor(500 + Math.random() * 4500),
    photos: o.photos ?? [
      "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1600&q=60"
    ],
    cha9a9aUrl: o.cha9a9aUrl ?? "https://cha9a9a.tn/",
    locationText: o.locationText ?? "Ariana",
    lat: o.lat ?? 36.866,
    lng: o.lng ?? 10.164,
    createdAt: new Date(now.getTime() - (i * 86400000)).toISOString()
  });

  const items = [
    mk(1, {
      title: "Opération urgente pour un enfant à Ariana",
      summary: "Cas urgent vérifié — besoin d'une intervention médicale.",
      description: "Nous cherchons un soutien rapide pour financer une intervention essentielle. Le cas est vérifié et transparent.",
      category: "Santé",
      urgency: "TRES_URGENT",
      status: "APPROVED",
      totalAmount: 3200,
      goalAmount: 8000,
      locationText: "Ariana",
      lat: 36.866,
      lng: 10.164,
      photos: [
        "https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&w=1600&q=60"
      ],
    }),
    mk(2, {
      title: "Fauteuil roulant pour un jeune étudiant",
      summary: "Cas vérifié — améliorer la mobilité et l'autonomie.",
      description: "Achat d’un fauteuil roulant adapté + accompagnement. Dignité, autonomie, transparence.",
      category: "Handicap",
      urgency: "URGENT",
      status: "APPROVED",
      totalAmount: 1100,
      goalAmount: 2500,
      locationText: "Tunis",
      lat: 36.806,
      lng: 10.181,
      photos: [
        "https://images.unsplash.com/photo-1520975912139-1f2ea6b44f51?auto=format&fit=crop&w=1600&q=60"
      ],
    }),
    mk(3, {
      title: "Rénovation d’un toit avant l’hiver",
      summary: "En attente de validation — urgence météo.",
      description: "Le toit est endommagé. L'association a soumis le cas, en attente de modération admin.",
      category: "Rénovation",
      urgency: "URGENT",
      status: "PENDING",
      totalAmount: 0,
      goalAmount: 4000,
      locationText: "Manouba",
      lat: 36.809,
      lng: 10.101,
      photos: [
        "https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?auto=format&fit=crop&w=1600&q=60"
      ],
    }),
  ];

  setDemoCases(items);
  return items;
}
