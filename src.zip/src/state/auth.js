const KEY = "soli_auth";

export function setAuth(payload) {
  localStorage.setItem(KEY, JSON.stringify(payload));
}
export function getAuth() {
  try { return JSON.parse(localStorage.getItem(KEY) || "null"); }
  catch { return null; }
}
export function clearAuth() {
  localStorage.removeItem(KEY);
}
export function getToken() {
  return getAuth()?.token || null;
}
