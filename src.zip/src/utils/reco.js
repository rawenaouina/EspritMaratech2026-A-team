export function haversineKm(lat1, lng1, lat2, lng2) {
  if ([lat1,lng1,lat2,lng2].some(v => v == null)) return null;
  const R = 6371;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat/2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng/2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export function scoreSimilar(base, other) {
  let s = 0;
  if (base.category && other.category && base.category === other.category) s += 4;
  if (base.urgency === other.urgency) s += 2;

  // priorité urgents
  if (other.urgency === "TRES_URGENT") s += 2;
  else if (other.urgency === "URGENT") s += 1;

  // distance si possible
  const d = haversineKm(base.lat, base.lng, other.lat, other.lng);
  if (d != null) {
    if (d < 5) s += 3;
    else if (d < 15) s += 2;
    else if (d < 40) s += 1;
  }
  return s;
}

export function getSimilarCases(current, all, limit = 3) {
  return all
    .filter(x => x.id !== current.id && x.status === "APPROVED")
    .map(x => ({ ...x, _score: scoreSimilar(current, x) }))
    .sort((a,b) => b._score - a._score)
    .slice(0, limit);
}

export function getNearbyUrgent(current, all, limit = 3) {
  return all
    .filter(x => x.id !== current.id && x.status === "APPROVED")
    .filter(x => x.urgency === "URGENT" || x.urgency === "TRES_URGENT")
    .map(x => {
      const d = haversineKm(current.lat, current.lng, x.lat, x.lng);
      return { ...x, _distance: d ?? 9999 };
    })
    .sort((a,b) => a._distance - b._distance)
    .slice(0, limit);
}
