export function applyThemeFromStorage() {
  const dark = localStorage.getItem("theme") === "dark";
  document.documentElement.classList.toggle("dark", dark);
}

export function applyA11yFromStorage() {
  const on = localStorage.getItem("a11y") === "1";
  document.documentElement.classList.toggle("a11y", on);
}

export function applyVisualFromStorage() {
  const b = Number(localStorage.getItem("brightness") || "1");
  const c = Number(localStorage.getItem("contrast") || "1");
  document.documentElement.style.setProperty("--brightness", String(b));
  document.documentElement.style.setProperty("--contrast", String(c));
}

export function isValidUrl(value) {
  try { new URL(value); return true; } catch { return false; }
}

export function toISODate(d) {
  try { return new Date(d).toISOString().slice(0, 10); } catch { return ""; }
}
