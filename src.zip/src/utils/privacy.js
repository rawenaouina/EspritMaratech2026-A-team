export function detectSensitive(text) {
  const issues = [];
  if (/(\b\d{8}\b)/.test(text)) issues.push("Téléphone possible détecté");
  if (/(\b\d{8,10}\b)/.test(text)) issues.push("CIN/Identifiant possible détecté");
  if (/(rue|avenue|av\.|route|quartier|imm\.|appartement)/i.test(text)) issues.push("Adresse possible détectée");
  if (/(\b[A-Z][a-z]+ [A-Z][a-z]+\b)/.test(text)) issues.push("Nom complet possible détecté");
  return issues;
}
