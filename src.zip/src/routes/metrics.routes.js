export function registerMetricsRoutes(app, { auth, db }) {
  app.get("/api/admin/metrics", auth(["ADMIN"]), async (req, res) => {
    await db.read();
    const cases = db.data.cases || [];

    const countStatus = (s) => cases.filter((c) => c.status === s).length;

    const byCategory = {};
    const byUrgency = {};
    cases.forEach((c) => {
      byCategory[c.category] = (byCategory[c.category] || 0) + 1;
      byUrgency[c.urgency] = (byUrgency[c.urgency] || 0) + 1;
    });

    const topViewed = [...cases]
      .filter((c) => c.status === "APPROVED")
      .sort((a, b) => (b.views || 0) - (a.views || 0))
      .slice(0, 5)
      .map((c) => ({ id: c.id, title: c.title, views: c.views || 0 }));

    res.json({
      status: {
        approved: countStatus("APPROVED"),
        pending: countStatus("PENDING"),
        rejected: countStatus("REJECTED"),
      },
      byCategory,
      byUrgency,
      topViewed,
    });
  });
}
