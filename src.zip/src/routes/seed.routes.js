import { nanoid } from "nanoid";

export function registerSeedRoutes(app, { auth, db }) {
  app.post("/api/admin/seed-demo", auth(["ADMIN"]), async (req, res) => {
    await db.read();
    db.data.cases ||= [];

    const demo = [
      {
        title: "Aide médicale urgente – enfant",
        summary: "Besoin de soutien pour traitement et analyses.",
        description: "Cas médical urgent. Documents disponibles sur demande.",
        category: "medical",
        urgency: "HIGH",
        address: "Ariana, Tunis",
        cha9a9aUrl: "https://cha9a9a.tn/demo1",
        photos: [
          "https://images.unsplash.com/photo-1580281658628-ef5d24a1a6b2?auto=format&fit=crop&w=1200&q=60",
          "https://images.unsplash.com/photo-1584515933487-779824d29309?auto=format&fit=crop&w=1200&q=60"
        ],
        status: "APPROVED",
        featured: true,
        disabilityTags: ["GENERAL_A11Y"]
      },
      {
        title: "Kit accessibilité – Handicap visuel",
        summary: "Canne + accessoires + accompagnement.",
        description: "Aide à l’équipement et orientation.",
        category: "accessibility",
        urgency: "MEDIUM",
        address: "Ariana, Tunis",
        cha9a9aUrl: "https://cha9a9a.tn/demo2",
        photos: ["https://images.unsplash.com/photo-1551847677-9f49d3f2f6d4?auto=format&fit=crop&w=1200&q=60"],
        status: "APPROVED",
        featured: true,
        disabilityTags: ["VISUAL"]
      },
      {
        title: "Appareillage – Handicap moteur",
        summary: "Fauteuil + rééducation",
        description: "Besoin d’appareillage et séances.",
        category: "medical",
        urgency: "HIGH",
        address: "Ariana, Tunis",
        cha9a9aUrl: "https://cha9a9a.tn/demo3",
        photos: ["https://images.unsplash.com/photo-1581595219315-a187dd40c322?auto=format&fit=crop&w=1200&q=60"],
        status: "APPROVED",
        featured: false,
        disabilityTags: ["MOTEUR"]
      }
    ];

    demo.forEach((d) => {
      db.data.cases.push({
        id: nanoid(),
        ownerEmail: "association@solicare.tn",
        createdAt: new Date().toISOString(),
        views: Math.floor(Math.random() * 200),
        donationsCount: Math.floor(Math.random() * 30),
        goalAmount: 500,
        ...d
      });
    });

    await db.write();
    res.json({ ok: true, added: demo.length });
  });
}
