import { translations } from "./translations";

const KEY = "lang";

export function getLang() {
  return localStorage.getItem(KEY) || "fr";
}

export function setLang(lang) {
  localStorage.setItem(KEY, lang);
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
}

export function t(key) {
  const lang = getLang();
  return translations[lang]?.[key] ?? translations.fr[key] ?? key;
}
