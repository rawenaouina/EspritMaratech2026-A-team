import { useEffect, useState } from "react";
import { getLang, setLang } from "./i18n";

export default function LanguageToggle() {
  const [lang, setState] = useState(getLang());

  useEffect(() => { setLang(lang); }, [lang]);

  return (
    <button
      className="px-3 py-2 rounded-xl border font-semibold"
      onClick={() => setState(v => v === "fr" ? "ar" : "fr")}
      aria-label="Changer langue"
    >
      {lang === "fr" ? "FR" : "AR"}
    </button>
  );
}
