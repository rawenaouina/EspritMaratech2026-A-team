const RAW = import.meta.env.VITE_API_URL;

// ✅ fallback safe si .env pas chargé
const API_URL = (RAW && RAW.trim()) ? RAW.replace(/\/$/, "") : "http://localhost:5000";

async function safeParse(r) {
  const text = await r.text();
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function buildUrl(path) {
  // path doit commencer par /
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${API_URL}${p}`;
}

async function request(path, options = {}, token) {
  const url = buildUrl(path);

  const r = await fetch(url, {
    ...options,
    headers: {
      ...(options.headers || {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    }
  });

  const payload = await safeParse(r);
  if (!r.ok) {
    const msg = payload?.message || payload?.error || "Erreur API";
    throw new Error(msg);
  }
  return payload;
}

export function apiGet(path, token) {
  return request(path, { method: "GET" }, token);
}

export function apiPost(path, body, token) {
  return request(
    path,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body ?? {})
    },
    token
  );
}

export function apiPatch(path, body, token) {
  return request(
    path,
    {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body ?? {})
    },
    token
  );
}
