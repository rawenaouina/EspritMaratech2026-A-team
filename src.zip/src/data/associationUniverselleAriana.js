export const UNIVERSelle_ARIANA = {
  name: "Universelle Cellule Ariana",
  location: "Ariana, Tunisie",
  facebook: "https://facebook.com/UniverselleAriana",
  email: "universellecelluleariana@gmail.com",
  mission:
    "Extension locale de l’association Universelle. Actions solidaires, aide aux familles, soutien humanitaire.",
  howToVolunteer:
    "Contacter via Facebook ou email, indiquer disponibilité, compétences et zone.",
};
